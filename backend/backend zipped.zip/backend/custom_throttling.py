from rest_framework.throttling import SimpleRateThrottle
from datetime import datetime
from django.conf import settings


class CustomRateLimiter(SimpleRateThrottle):
    rate = '100/hour'  # 100 requests per hour

    def get_cache_key(self, request, view):
        # Customize the cache key based on user or IP address
        if request.user.is_authenticated:
            return f"user_{request.user.id}"
        else:
            return f"ip_{request.META.get('REMOTE_ADDR')}"

    def allow_request(self, request, view):
        # Get the cache key for the current request
        cache_key = self.get_cache_key(request, view)

        # Get the rate limit (e.g., '100/hour' -> 100 requests per hour)
        rate, unit = self.parse_rate(self.rate)

        # Calculate the time window for the rate limit
        now = datetime.now()
        window_start = now.replace(microsecond=0, second=0, minute=0)
        window_end = window_start.replace(hour=window_start.hour + 1)

        # Calculate the number of requests made within the time window
        count = self.get_request_count(cache_key, window_start, window_end)

        # Check if the request rate limit is exceeded
        if count > rate:
            return False
        else:
            # Increment the request count for the current window
            self.throttle_increment(cache_key, window_start)
            return True
