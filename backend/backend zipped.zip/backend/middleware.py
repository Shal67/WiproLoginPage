import asyncio
from aiohttp import ClientSession  # Import ClientSession from aiohttp
from asyncio import get_event_loop  # Import get_event_loop from asyncio
from django.http import HttpResponse


class RateLimitMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.client_session = None  # Initialize to None

    async def __call__(self, request):
        # Define your rate limit settings here
        rate_limit = 100  # Maximum number of requests per window
        window_seconds = 3600  # 1 hour window

        # Construct a key to identify the client (e.g., IP address)
        client_key = request.META.get('REMOTE_ADDR')

        if not self.client_session:
            # Create a new asyncio event loop if one doesn't exist
            loop = get_event_loop()

            # Create an aiohttp ClientSession within the event loop
            self.client_session = ClientSession(loop=loop)

        # Check the rate limit using aiohttp
        async with self.client_session.get('http://localhost:3000', params={
            'key': client_key,
            'rate_limit': rate_limit,
            'window_seconds': window_seconds,
        }) as response:
            if response.status != 200:
                # Rate limit exceeded, return an error response
                return HttpResponse('Rate limit exceeded', status=429)

        # Rate limit not exceeded, allow the request to proceed
        response = await self.get_response(request)
        return response
